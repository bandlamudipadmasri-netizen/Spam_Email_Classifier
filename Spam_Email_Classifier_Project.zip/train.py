import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from joblib import dump

df = pd.read_csv("dataset/emails.csv")

model = Pipeline([
    ("tfidf", TfidfVectorizer()),
    ("clf", MultinomialNB())
])

model.fit(df["text"], df["label"])
dump(model, "models/spam_model.pkl")
print("Model saved.")
