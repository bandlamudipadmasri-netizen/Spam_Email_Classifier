# Spam Email Classifier

1. pip install -r requirements.txt
2. python train.py
3. python app.py

Open: http://127.0.0.1:5000
