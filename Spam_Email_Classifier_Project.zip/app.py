from flask import Flask, render_template, request
from joblib import load
import os

app = Flask(__name__)
model = load("models/spam_model.pkl") if os.path.exists("models/spam_model.pkl") else None

@app.route("/", methods=["GET","POST"])
def home():
    result = ""
    if request.method == "POST" and model:
        msg = request.form["email"]
        result = model.predict([msg])[0]
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
